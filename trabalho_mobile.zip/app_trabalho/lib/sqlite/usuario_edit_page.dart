import 'package:app_trabalho/model/usuario.dart';
import 'package:flutter/material.dart';

class UsuariosEditPage extends StatefulWidget {
  const UsuariosEditPage({super.key, this.selecionado});

  final Usuario? selecionado;

  @override
  State<UsuariosEditPage> createState() => _UsuariosEditPageState();
}

class _UsuariosEditPageState extends State<UsuariosEditPage> {
  final _nomeCon = TextEditingController();
  final _emailCon = TextEditingController();
  // final _senhaCon = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nomeCon.text = widget.selecionado!.nome!;
    _emailCon.text = widget.selecionado!.email!;
    // _senhaCon.text = widget.selecionado!.senha!;
  }

  void salvar() {
    widget.selecionado!.nome = _nomeCon.text;
    widget.selecionado!.email = _emailCon.text;
    // widget.selecionado!.senha = _senhaCon.text;
    widget.selecionado!.interesses = [];
    Navigator.pop(context, 'Salvar');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cadastro de Usuario'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            TextFormField(
              controller: _nomeCon,
              keyboardType: TextInputType.text,
              maxLength: 20,
              readOnly: true,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Nome',
              ),
            ),
            TextFormField(
              controller: _emailCon,
              keyboardType: TextInputType.text,
              maxLength: 20,
              readOnly: true,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Email',
              ),
            ),
            // TextFormField(
            //   controller: _senhaCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'Senha',
            //   ),
            // ),
            // TextFormField(
            //   controller: _interessesCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'interesses',
            //   ),
            // ),
            Row(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    child: const Text('Voltar'),
                    onPressed: () {
                      Navigator.pop(context, 'Voltar');
                    },
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    child: const Text('Enviar mensagem'),
                    onPressed: () {
                      salvar();
                    },
                  ),
                ),
                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: ElevatedButton(
                //     child: const Text('Excluir'),
                //     onPressed: () {
                //       Navigator.pop(context, 'Excluir');
                //     },
                //   ),
                // ),
              ],
            )
          ],
        )),
      ),
    );
  }
}
