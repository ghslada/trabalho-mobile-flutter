import 'dart:async';

import 'package:app_trabalho/model/usuario.dart';
import 'package:flutter/widgets.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class UsuarioHelper {
  static final UsuarioHelper _instance = UsuarioHelper.internal();
  factory UsuarioHelper() => _instance;
  UsuarioHelper.internal();
  Database? _db;

  Future<Database> get db async {
    if (_db != null) {
      return _db!;
    } else {
      _db = await initDb();
      return _db!;
    }
  }

  Future<Database> initDb() async {
    final path = join(await getDatabasesPath(), "Usuarios_base.db");
    return await openDatabase(path, version: 1,
        onCreate: (Database db, int newVers) async {
      await db.execute("CREATE TABLE Usuario(id TEXT PRIMARY KEY, " +
          "nome TEXT, email TEXT, telefone TEXT)");
    });
  }

  Future<List<Usuario>> obterTodos() async {
    Database dbContact = await db;
    List listMap = await dbContact.rawQuery("SELECT * FROM Usuario");
    List<Usuario> listContact = List.empty(growable: true);
    for (Map<String, dynamic> m in listMap) {
      Usuario c = Usuario.fromMap(m);
      listContact.add(c);
    }
    return listContact;
  }

  Future<Usuario> inserir(Usuario contact) async {
    Database dbContact = await db;
    int? idNew = Sqflite.firstIntValue(
        await dbContact.rawQuery("SELECT MAX(id) FROM Usuario"));
    if (idNew == null) {
      idNew = 1;
    } else {
      idNew = idNew + 1;
    }
    contact.id = idNew.toString();
    await dbContact.insert('Usuario', contact.toMap());
    return contact;
  }

  Future<int> alterar(Usuario obj) async {
    Database dbContact = await db;
    return await dbContact
        .update('Usuario', obj.toMap(), where: "id = ?", whereArgs: [obj.id]);
  }

  Future<int> excluir(String idDel) async {
    Database dbContact = await db;
    return await dbContact
        .delete('Usuario', where: "id = ?", whereArgs: [idDel]);
  }

  Future<Usuario?> getObjeto(String idFind) async {
    Database dbContact = await db;
    List<Map<String, dynamic>> maps = await dbContact.query('Usuario',
        columns: ['id', 'nome'], where: "id = ?", whereArgs: [idFind]);
    if (maps.isNotEmpty) {
      return Usuario.fromMap(maps.first);
    } else {
      return null;
    }
  }

  Future<int?> getNumber() async {
    Database dbContact = await db;
    return Sqflite.firstIntValue(
        await dbContact.rawQuery("SELECT COUNT(*) FROM Usuario"));
  }

  Future close() async {
    Database dbContact = await db;
    dbContact.close();
  }
}
