import 'package:app_trabalho/model/usuario.dart';
import 'package:flutter/material.dart';

class AuthenticationValidator {
  
  static validate(BuildContext context, Usuario usuario) {

    if( usuario.id == null ) {

      Navigator.pop(context);

    }

  }
}
