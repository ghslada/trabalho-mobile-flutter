import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/sqlite/login.dart';
import 'package:app_trabalho/sqlite/usuario_edit_page.dart';
import 'package:app_trabalho/sqlite/usuario_list_page.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key, this.usuarioLogado});

  final Usuario? usuarioLogado;

  void logout(context) {
    while (Navigator.canPop(context)) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                children: [
                  Text(
                    'Bem vindo ${usuarioLogado!.nome!}',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                  ElevatedButton(
                      onPressed: () {
                        logout(context);
                      },
                      child: const Text('Sair'))
                ],
              ),
            ),
            // ListTile(
            //   leading: const Icon(Icons.message),
            //   title: const Text('Contador'),
            //   onTap: () {
            //     Navigator.of(context).pop();
            //     Navigator.of(context).pushNamed('/contador');
            //   },
            // ),
            // ListTile(
            //   leading: const Icon(Icons.account_circle),
            //   title: const Text('Sobre'),
            //   onTap: () {
            //     Navigator.of(context).pop();
            //     Navigator.of(context).pushNamed('/sobre');
            //   },
            // ),
            // ListTile(
            //   leading: const Icon(Icons.account_circle),
            //   title: const Text('Dias Vividos'),
            //   onTap: () {
            //     Navigator.of(context).pop();
            //     Navigator.of(context).pushNamed('/diasVividos');
            //   },
            // ),
            // ListTile(
            //   leading: const Icon(Icons.account_circle),
            //   title: const Text('Dias Vividos OO'),
            //   onTap: () {
            //     Navigator.of(context).pop();
            //     Navigator.of(context).pushNamed('/diasVividosOo');
            //   },
            // ),
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Usuários'),
              onTap: () {
                Navigator.of(context).pop();
                // Navigator.of(context).pushNamed('/usuario');
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => UsuariosListPage(usuarioLogado: usuarioLogado),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // const Image(image: AssetImage('images/upf.png')),
            Text('Bem vindo ${usuarioLogado!.nome!}'),
            // ElevatedButton(
            //   onPressed: () {
            //     Navigator.of(context).pushNamed('/cadastro');
            //   },
            //   child: const Text('Cadastro'),
            // ),
            // ElevatedButton(
            //   onPressed: () {
            //     Navigator.of(context).pushNamed('/login');
            //   },
            //   child: const Text('Login'),
            // ),
          ],
        ),
      ),
    );
  }
}
