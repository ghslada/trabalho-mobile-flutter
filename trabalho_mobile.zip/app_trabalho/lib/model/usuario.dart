class Usuario {
  String? id;
  String? nome;
  String? email;
  String? senha;
  List? interesses;

  Usuario() {
    id = null;
    nome = "";
    email = "";
    senha = "";
    interesses = [];
  }

  Usuario.init(this.id, this.nome, this.email, this.senha, this.interesses);

  factory Usuario.fromMap(Map<String, dynamic> json) {
    return Usuario.init(
        json['_id'], json['nome'], json['email'], json['senha'], json['interesses']);
  }

  Map<String, dynamic> toMap() =>
      {'_id': id, 'nome': nome, 'email': email, 'senha': senha, 'interesses': interesses};

  @override
  toString() {
    return '$nome - $email';
  }

  bool operator ==(other) {
    return (other is Usuario && other.id == id);
  }
}
