import 'package:app_trabalho/model/usuario.dart';

class Mensagem {
  String? id;
  // String? titulo;
  String? descricao;
  String? criadoPor;
  List<String>? enviadaPara;
  List? curtidas;

  Mensagem() {
    id = null;
    descricao = "";
    criadoPor = '';
    enviadaPara = [];
    curtidas = [];
  }

  Mensagem.init(this.id, this.descricao, this.criadoPor, enviadaPara, this.curtidas);

  factory Mensagem.fromMap(Map<String, dynamic> json) {
    return Mensagem.init(
        json['id'], json['descricao'], json['criadoPor'], json['enviadaPara'], json['curtidas']);
  }

  Map<String, dynamic> toMap() =>
      {'id': id, 'descricao': descricao, 'criadoPor': criadoPor, 'enviadaPara':enviadaPara, 'curtidas': curtidas };

  @override
  toString() {
    return '$descricao';
  }

  bool operator ==(other) {
    return (other is Mensagem && other.id == id);
  }
}
