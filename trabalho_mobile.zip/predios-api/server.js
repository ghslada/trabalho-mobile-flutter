console.log("Nosso Servidor Rodando...")

require("dotenv").config();

// user express
const express = require('express');
const app = express();
app.use(express.json()); // Para tratar json

var cors = require('cors');
app.use(cors({ origin: '*' }));

// preparar para responder ao get
app.get('/', (req, res) => {
    res.send('Atendida a requisição GET!!');
});

const port = process.env.API_PORT || 3100;

app.listen(port, function () {
    console.log('API rodando na porta '+port);
    console.log(`Testar por http://localhost:${port}`);
});

require('./mongo');

// app.get('/a', (req, res) => {
//     req.
// }) 


const Usuario = require('./service/UsuarioSrv');
Usuario(app);

const Curtida = require('./service/CurtidaSrv');
Curtida(app);

const Interesse = require('./service/InteresseSrv');
Interesse(app);

const Mensagem = require('./service/MensagemSrv');
Mensagem(app);

const Grupo = require('./service/GrupoSrv');
Grupo(app);

