const Mensagem = require('../model/MensagemSchema');

module.exports = (app) => {

    app.get('/Mensagem', (req, res) => {

        // var port = req.app.settings.port || cfg.port;

        const url = req.url;

        let params = url.split('?',2)[1];

        let idx = 1;

        // a=b&c=d

        const paramsList = [];

        console.log(params);

        const paramsKeyAndValue = params.split('&');

        let criadaPor = '';

        let enviadaPara = '';

        console.log(paramsKeyAndValue);

        for ( let paramKeyAndValue of paramsKeyAndValue ) {

            console.log(paramKeyAndValue);

            if ( paramKeyAndValue.includes( 'criadaPor' ) ) {

                criadaPor = paramKeyAndValue.split('=')[1];

            } else {

                if ( paramKeyAndValue.includes( 'enviadaPara' ) ) {

                    enviadaPara = paramKeyAndValue.split('=')[1];

                }

            }

        }

        console.log('Usuario logado: '+criadaPor);


        console.log('Usuario selecionado: '+enviadaPara);

        Mensagem.find((err, objetos) => {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(objetos);
        }).populate('criadaPor')
        .populate( {path: 'curtidas', populate: { path: 'criadaPor' }})
        .populate('enviadaPara').sort({ createdAt: 1 }); // -1 decrescente  1 crescente
    });

    app.post('/Mensagem', (req, res, next) => {
        let obj = new Mensagem(req.body);
        obj.save((err, obj) => {
            if (err) res.status(400).send(err.message);
            console.log('mensagem salva!');
            res.status(200).json(obj);
        });
    });

    app.put('/Mensagem', (req, res) => {
        let obj = new Mensagem(req.body);
        const error = obj.validateSync();
        if (error) {
            res.status(400).send(error.message);
            return;
        };
        Mensagem.updateOne({ _id: obj._id }, obj, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        });
    });

    app.delete('/Mensagem/:id', (req, res) => {
        Mensagem.deleteOne({ _id: req.params.id }, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json("{message:'ok'}");
        });

    });

    app.get('/Mensagem/:id', (req, res) => {
        Mensagem.findOne({ _id: req.params.id }, function (err, obj) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        }).populate('criadaPor').populate('curtidas').populate('enviadaPara');
    });

    app.get('/Mensagem/filtro/:filtro', (req, res) => {
        Mensagem.find({
            $or: [
                // POSSIVEL FILTRAR PELO CONTEUDO DA MENSAGEM, PARA QUEM FOI ENVIADA OU POR QUEM FOI CRIADA
                { descricao: { $regex: req.params.filtro, $options: "i" } },
                { enviadaPara: { $regex: req.params.filtro, $options: "i" } },
                { criadaPor: { $regex: req.params.filtro, $options: "i" } },
            ],
        }, function (err) {
            if (err)
                res.status(400).send(err.message);
            res.json(objetos);
        }).sort({ createdAt: 1 }); // -1 decrescente 1 crescente
    });
};

