const mongoose = require("mongoose");

const Grupo = new mongoose.Schema({
    titulo: { type: String, required: true, unique: true },
    descricao: { type: String },
    participantes: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Usuario',
    }],
    criadoPor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Usuario',
        require: true,
    },
    interesses: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Interesse',
        }
    ],
    mensagens: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Mensagem',
        }
    ]
});

module.exports = mongoose.model("Grupo", Grupo);