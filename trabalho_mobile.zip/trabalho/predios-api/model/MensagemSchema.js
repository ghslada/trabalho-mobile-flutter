const mongoose = require("mongoose");
const timestamps = require('mongoose-timestamp');

const Mensagem = new mongoose.Schema({
    descricao: { type: String, required: true },
    criadaPor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Usuario',
        require: true,
    },
    enviadaPara: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Usuario',
        },
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Grupo',
        },
    ],
    curtidas: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Curtida',
        },
    ]
});

Mensagem.plugin(timestamps); // automatically adds createdAt and updatedAt timestamps

module.exports = mongoose.model("Mensagem", Mensagem);