const mongoose = require("mongoose");

const Curtida = new mongoose.Schema({
    criadaPor: { 
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Usuario', 
        require: true,
    },
    curtidas: [
        { 
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Mensagem', 
            require: true,
        }
    ],
});

module.exports = mongoose.model("Curtida", Curtida);