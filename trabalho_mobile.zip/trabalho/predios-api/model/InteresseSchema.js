const mongoose = require("mongoose");
const UsuarioSchema = require("./UsuarioSchema");

const Interesse = new mongoose.Schema({
    titulo: { type: String, required: true, unique: true },
    descricao: { type: String, required: true, unique:true },
    criadoPor: { 
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Usuario', 
        require: true,
    }
});

module.exports = mongoose.model("Interesse", Interesse);