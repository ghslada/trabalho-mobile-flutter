const Curtida = require('../model/CurtidaSchema');

module.exports = (app) => {
    app.get('/Curtida', (req, res) => {
        Curtida.find((err, objetos) => {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(objetos);
        }).populate('curtidas')//.sort({ criadaPor: 1 }); // -1 decrescente  1 crescente
    });

    app.post('/Curtida', (req, res, next) => {
        let obj = new Curtida(req.body);
        obj.save((err, obj) => {
            if (err) res.status(400).send(err.message);
            res.status(200).json(obj);
        });
    });

    app.put('/Curtida', (req, res) => {
        let obj = new Curtida(req.body);
        const error = obj.validateSync();
        if (error) {
            res.status(400).send(error.message);
            return;
        };
        Curtida.updateOne({ _id: obj._id }, obj, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        });
    });

    app.delete('/Curtida/:id', (req, res) => {
        Curtida.deleteOne({ _id: req.params.id }, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json("{message:'ok'}");
        });

    });

    app.get('/Curtida/:id', (req, res) => {
        Curtida.findOne({ _id: req.params.id }, function (err, obj) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        }).populate('curtidas');
    });

};

