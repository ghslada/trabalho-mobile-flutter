const Grupo = require('../model/GrupoSchema');

module.exports = (app) => {
    app.get('/Grupo', (req, res) => {
        Grupo.find((err, objetos) => {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(objetos);
        })//.populate('predio').populate('tipo').sort({ descricao: 1 }); // -1 decrescente  1 crescente
    });

    app.post('/Grupo', (req, res, next) => {
        let obj = new Grupo(req.body);
        obj.save((err, obj) => {
            if (err) res.status(400).send(err.message);
            res.status(200).json(obj);
        });
    });

    app.put('/Grupo', (req, res) => {
        let obj = new Grupo(req.body);
        const error = obj.validateSync();
        if (error) {
            res.status(400).send(error.message);
            return;
        };
        Grupo.updateOne({ _id: obj._id }, obj, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        });
    });

    app.delete('/Grupo/:id', (req, res) => {
        Grupo.deleteOne({ _id: req.params.id }, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json("{message:'ok'}");
        });

    });

    app.get('/Grupo/:id', (req, res) => {
        Grupo.findOne({ _id: req.params.id }, function (err, obj) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        });
    });

    app.get('/Grupo/filtro/:filtro', (req, res) => {
        Grupo.find({
            $or: [
                // POSSIVEL FILTRAR PELO TITULO OU DESCRICAO
                { titulo: { $regex: req.params.filtro, $options: "i" } },
                { descricao: { $regex: req.params.filtro, $options: "i" } },
            ],
        }, function (err) {
            if (err)
                res.status(400).send(err.message);
            res.json(objetos);
        }).sort({ titulo: 1 }); // -1 decrescente 1 crescente
    });
};

