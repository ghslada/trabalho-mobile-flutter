const Interesse = require('../model/InteresseSchema');

module.exports = (app) => {
    app.get('/Interesse', (req, res) => {
        Interesse.find((err, objetos) => {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(objetos);
        }).sort({ titulo: 1 }); // -1 decrescente  1 crescente
    });

    app.post('/Interesse', (req, res, next) => {
        let obj = new Interesse(req.body);
        obj.save((err, obj) => {
            if (err) res.status(400).send(err.message);
            res.status(200).json(obj);
        });
    });

    app.put('/Interesse', (req, res) => {
        let obj = new Interesse(req.body);
        const error = obj.validateSync();
        if (error) {
            res.status(400).send(error.message);
            return;
        };
        Interesse.updateOne({ _id: obj._id }, obj, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        });
    });

    app.delete('/Interesse/:id', (req, res) => {
        Interesse.deleteOne({ _id: req.params.id }, function (err) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json("{message:'ok'}");
        });

    });

    app.get('/Interesse/:id', (req, res) => {
        Interesse.findOne({ _id: req.params.id }, function (err, obj) {
            if (err) {
                res.status(400).send(err.message);
            };
            res.status(200).json(obj);
        });
    });

    app.get('/Interesse/filtro/:filtro', (req, res) => {
        Interesse.find({
            $or: [
                // POSSIVEL FILTRAR PELO TITULO OU DESCRICAO
                { titulo: { $regex: req.params.filtro, $options: "i" } },
                { descricao: { $regex: req.params.filtro, $options: "i" } },
            ],
        }, function (err) {
            if (err)
                res.status(400).send(err.message);
            res.json(objetos);
        }).sort({ titulo: 1 }); // -1 decrescente 1 crescente
    });
};

