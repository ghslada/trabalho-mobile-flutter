package com.example.app_trabalho

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
