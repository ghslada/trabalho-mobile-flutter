import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/pages/home.dart';
import 'package:app_trabalho/sqlite/cadastro_usuario.dart';
import 'package:app_trabalho/sqlite/login.dart';
import 'package:app_trabalho/sqlite/login_form.dart';
import 'package:app_trabalho/sqlite/usuario_list_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),
      routes: {
        // '/sobre': (context) => const SobrePage(),
        // '/contador': (context) => const ContadorPage(title: 'Contador'),
        // '/diasVividos': (context) =>
        //     const DiasVividosPage(title: 'Dias Vividos'),
        // '/diasVividosOo': (context) =>
        //     const DiasVividosOoPage(title: 'Dias Vividos OO'),
        '/home': (context) =>
            const HomePage(),
        '/usuario': (context) =>
            const UsuariosListPage(title: 'Usuarios SQLite'),
        '/cadastro': (context) =>
            CadastroUsuarioPage(selecionado: Usuario()),
        '/login': (context) =>
            LoginFormPage(usuarioLogado: Usuario())
      },
    );
  }
}
