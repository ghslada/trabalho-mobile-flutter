// import 'package:app_trabalho/model/Mensagem.dart';
import 'package:app_trabalho/model/mensagem.dart';
import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/sqlite/mensagem_helper_api.dart';
import 'package:app_trabalho/util/dialogos.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

class MensagemPage extends StatefulWidget {
  const MensagemPage({super.key, this.selecionado, this.usuarioLogado});

  // final Mensagem? msg;
  final Usuario? selecionado;
  final Usuario? usuarioLogado;

  @override
  State<MensagemPage> createState() => _MensagemPageState();
}

class _MensagemPageState extends State<MensagemPage> {
  final MensagensDb = MensagemHelperApi();
  final _descricaoCon = TextEditingController();

  List<Mensagem> mensagens = [];
  Usuario? _selecionado = Usuario();
  Usuario? _usuarioLogado = Usuario();

  Mensagem? novaMensagem = Mensagem();

  @override
  void initState() {
    // NECESSARIO BUSCAR MENSAGENS DO USUARIO LOGADO COM DESTINO A PESSOA SELECIONADA
    // E MENSAGENS RECEBIDAS DA PESSOA SELECIONADA
    super.initState();
    buscarMensagens();
  }

  void buscarMensagens() {
    _descricaoCon.text = '';
    _selecionado = widget.selecionado!;
    _usuarioLogado = widget.usuarioLogado;

    MensagensDb.obterTodos(_usuarioLogado!.id!,
            _selecionado!.id == null ? _usuarioLogado!.id! : _selecionado!.id!)
        .then((list) {
      setState(() {
        mensagens = list;
      });
      print(mensagens);
    });

    // mensagens.add(new Mensagem());
  }

  void selecionar(int index) {
    print('Selecionou indice: ${index}');
  }

  void salvar() {
    if (_usuarioLogado != null) {
      novaMensagem?.criadoPor = _usuarioLogado!.id!;
    }

    novaMensagem?.enviadaPara?.add(_selecionado!.id!);
    novaMensagem?.descricao = _descricaoCon.text;

    List<Mensagem> mensagensUpdate = [];

    mensagensUpdate.addAll(mensagens);

    MensagensDb.inserir(novaMensagem!).then((res) {
      mensagensUpdate.add(novaMensagem!);

      setState(() {
        mensagens = mensagensUpdate;
        _descricaoCon.text = '';
      });

      Dialogos.showAlertDialog(context, 'Dados inseridos com sucesso!');
    });
    // widget.selecionado!.descricao = _descricaoCon.text;

    // widget.selecionado!.email = _emailCon.text;
    // widget.selecionado!.senha = _senhaCon.text;
    // widget.selecionado!.interesses = [];
    // Navigator.pop(context, 'Salvar');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${_selecionado!.nome!}'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          // Expanded(
          //     child: GroupedListView(
          //   padding: const EdgeInsets.all(8),
          //   elements: mensagens,
          //   groupBy: (Mensagem mensagem) => DateTime(2022),
          //   itemBuilder: (context, Mensagem mensagem) => Card(
          //     elevation: 8,
          //     child: Padding(
          //       padding: const EdgeInsets.all(12),
          //       child: Text(mensagem.descricao!),
          //     ),
          //   ),
          // )),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(2.5),
              itemCount: mensagens.length,
              scrollDirection: Axis.vertical,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  title: Row(children: <Widget>[
                    // Text('Text'),
                    Padding(
                      padding: mensagens[index].criadoPor! == _usuarioLogado!.id
                          ? const EdgeInsets.only(left: 160.0)
                          : const EdgeInsets.only(left: 0.0),
                      child: SizedBox(
                        width: 200,
                        child: 
                        // Padding(
                        //   padding:
                        //       mensagens[index].criadoPor! == _usuarioLogado!.id
                        //           ? const EdgeInsets.only(left: 50.0)
                        //           : const EdgeInsets.only(left: 0.0),
                        //   child:
                           Text(
                            mensagens[index]
                                .descricao!,
                                textAlign: mensagens[index].criadoPor! == _usuarioLogado!.id
                                  ? TextAlign.end
                                  : TextAlign.start,
                                 //textAlign: mensagens[index].criadoPor! == _usuarioLogado!.idTextAlign.right//mensagens[index].criadoPorPopulated!.id == _usuarioLogado!.id? TextAlign.right : TextAlign.left,),
                          ),
                        // ),
                      ),
                    )
                    // Text('${index}'),
                  ]),
                  onTap: () => selecionar(index),
                );
              },
              separatorBuilder: (BuildContext context, int index) =>
                  const Divider(),
            ),
          ),
          Container(
            color: Colors.blueGrey[50],
            child: TextField(
              controller: _descricaoCon,
              keyboardType: TextInputType.text,
              // maxLength: 20,
              // readOnly: true,
              onEditingComplete: () => {salvar()},
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
                // border: OutlineInputBorder(),
                labelText: 'Digite sua mensagem...',
              ),
            ),
            // TextFormField(
            //   controller: _emailCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   readOnly: true,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'Email',
            //   ),
            // ),
            // TextFormField(
            //   controller: _senhaCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'Senha',
            //   ),
            // ),
            // TextFormField(
            //   controller: _interessesCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'interesses',
            //   ),
            // ),
            // Row(
            //   children: <Widget>[
            //     // Padding(
            //     //   padding: const EdgeInsets.all(8.0),
            //     //   child: ElevatedButton(
            //     //     child: const Text('Voltar'),
            //     //     onPressed: () {
            //     //       Navigator.pop(context, 'Voltar');
            //     //     },
            //     //   ),
            //     // ),

            //     Padding(
            //       padding: const EdgeInsets.all(8.0),
            //       child: ElevatedButton(
            //         child: const Text('Enviar mensagem'),
            //         onPressed: () {
            //           salvar();
            //         },
            //       ),
            //     ),
            //     // Padding(
            //     //   padding: const EdgeInsets.all(8.0),
            //     //   child: ElevatedButton(
            //     //     child: const Text('Excluir'),
            //     //     onPressed: () {
            //     //       Navigator.pop(context, 'Excluir');
            //     //     },
            //     //   ),
            //     // ),
            //   ],
            // )
          ),
        ],
      ),
    );
  }
}
