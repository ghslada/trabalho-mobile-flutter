// import 'package:app_trabalho/model/Mensagem.dart';
import 'package:app_trabalho/model/mensagem.dart';
import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/sqlite/mensagem_helper_api.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

class MensagemPage extends StatefulWidget {
  const MensagemPage({super.key, this.selecionado, this.usuarioLogado});

  // final Mensagem? msg;
  final Usuario? selecionado;
  final Usuario? usuarioLogado;

  @override
  State<MensagemPage> createState() => _MensagemPageState();
}

class _MensagemPageState extends State<MensagemPage> {
  final _MensagensDb = MensagemHelperApi();
  final _descricaoCon = TextEditingController();
  List<Mensagem> _mensagens = List.empty();
  Usuario? _selecionado = Usuario();
  Usuario? _usuarioLogado = Usuario();
  // final _emailCon = TextEditingController();
  // final _emailCon = TextEditingController();
  // final _emailCon = TextEditingController();
  // final _senhaCon = TextEditingController();

  @override
  void initState() {
    // NECESSARIO BUSCAR MENSAGENS DO USUARIO LOGADO COM DESTINO A PESSOA SELECIONADA
    // E MENSAGENS RECEBIDAS DA PESSOA SELECIONADA

    _descricaoCon.text = '';
    _selecionado = widget.selecionado!;
    _usuarioLogado = widget.usuarioLogado;

    super.initState();

    _MensagensDb.obterTodos(_usuarioLogado!.id!,
            _selecionado!.id == null ? _usuarioLogado!.id! : _selecionado!.id!)
        .then((list) {
          print(list);
      setState(() {
        _mensagens = list;
      });
    });
    // _emailCon.text = widget.selecionado!.email!;
    // _senhaCon.text = widget.selecionado!.senha!;
  }

  void salvar() {
    // widget.selecionado!.descricao = _descricaoCon.text;

    // widget.selecionado!.email = _emailCon.text;
    // widget.selecionado!.senha = _senhaCon.text;
    // widget.selecionado!.interesses = [];
    // Navigator.pop(context, 'Salvar');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${_selecionado!.nome!}'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          // Expanded(
          //     child: GroupedListView(
          //   padding: const EdgeInsets.all(8),
          //   elements: _mensagens,
          //   groupBy: (Mensagem mensagem) => DateTime(2022),
          //   itemBuilder: (context, Mensagem mensagem) => Card(
          //     elevation: 8,
          //     child: Padding(
          //       padding: const EdgeInsets.all(12),
          //       child: Text(mensagem.descricao!),
          //     ),
          //   ),
          // )),
          Container(
            color: Colors.blueGrey[50],
            child: TextField(
              controller: _descricaoCon,
              keyboardType: TextInputType.text,
              // maxLength: 20,
              // readOnly: true,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.all(12),
                // border: OutlineInputBorder(),
                labelText: 'Digite sua mensagem...',
              ),
            ),
            // TextFormField(
            //   controller: _emailCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   readOnly: true,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'Email',
            //   ),
            // ),
            // TextFormField(
            //   controller: _senhaCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'Senha',
            //   ),
            // ),
            // TextFormField(
            //   controller: _interessesCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'interesses',
            //   ),
            // ),
            // Row(
            //   children: <Widget>[
            //     // Padding(
            //     //   padding: const EdgeInsets.all(8.0),
            //     //   child: ElevatedButton(
            //     //     child: const Text('Voltar'),
            //     //     onPressed: () {
            //     //       Navigator.pop(context, 'Voltar');
            //     //     },
            //     //   ),
            //     // ),

            //     Padding(
            //       padding: const EdgeInsets.all(8.0),
            //       child: ElevatedButton(
            //         child: const Text('Enviar mensagem'),
            //         onPressed: () {
            //           salvar();
            //         },
            //       ),
            //     ),
            //     // Padding(
            //     //   padding: const EdgeInsets.all(8.0),
            //     //   child: ElevatedButton(
            //     //     child: const Text('Excluir'),
            //     //     onPressed: () {
            //     //       Navigator.pop(context, 'Excluir');
            //     //     },
            //     //   ),
            //     // ),
            //   ],
            // )
          ),
        ],
      ),
    );
  }
}
