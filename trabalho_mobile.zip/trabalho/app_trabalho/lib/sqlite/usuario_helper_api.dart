import 'package:app_trabalho/model/usuario.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UsuarioHelperApi {
  String uri = "http://localhost:3000";
  Future<List<Usuario>> obterTodos() async {
    final res = await http.get(Uri.parse('$uri/Usuario'));
    if (res.statusCode == 200) {
      List jsonList = json.decode(res.body);
      List<Usuario> listContact = List.empty(growable: true);
      for (Map<String, dynamic> m in jsonList) {
        Usuario c = Usuario.fromMap(m);
        listContact.add(c);
      }
      return listContact;
    } else {
      throw Exception('Erro ao recuperar os objetos.');
    }
    // return [];
  }

  Future<Usuario?> inserir(Usuario contact) async {
    final res = await http.post(Uri.parse('$uri/Usuario'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(contact.toMap()));
    return Usuario.fromMap(jsonDecode(res.body));
    // return Usuario();
  }

  Future<Usuario?> login(Usuario contact) async {
    final res = await http.post(Uri.parse('$uri/Usuario/login'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(contact.toMap()));
    return Usuario.fromMap(jsonDecode(res.body));
    // return Usuario();
  }

  Future<String?> alterar(Usuario contact) async {
    final res = await http.put(Uri.parse('$uri/Usuario'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(contact.toMap()));
    final body =  jsonDecode(res.body);

    return body._id;
    // return 0;
  }

  Future<String> excluir(String idDel) async {
    final res = await http.delete(Uri.parse('$uri/Usuario/$idDel'));
    final body =  jsonDecode(res.body);

    return body._id;
    // return res.body;
    // return 0;
  }

  Future<Usuario> getObjeto(int idFind) async {
      final res = await http.get(Uri.parse('$uri/Usuario/$idFind'));
      if (res.statusCode == 200) {
        Usuario c = Usuario.fromMap(jsonDecode(res.body));
        return c;
      } else {
        throw Exception('Erro ao recuperar o objeto.');
      }
    // return Usuario();

  }

}
