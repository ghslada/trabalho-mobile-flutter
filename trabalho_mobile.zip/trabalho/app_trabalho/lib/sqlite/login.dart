import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/sqlite/Usuario_helper_api.dart';
import 'package:app_trabalho/util/dialogos.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Grupos de chat sobre interesses')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // const Image(image: AssetImage('images/upf.png')),
            const Text('Bem vindo... \nO intuito desse app é criar grupos de chat \nsobre interesses em comum.\n'),
            
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed('/cadastro');
              },
              child: const Text('Cadastro'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed('/login');
              },
              child: const Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
