import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/pages/home.dart';
import 'package:app_trabalho/sqlite/Usuario_helper_api.dart';
import 'package:app_trabalho/util/dialogos.dart';
import 'package:flutter/material.dart';

class LoginFormPage extends StatefulWidget {
  LoginFormPage({super.key, this.usuarioLogado});

  Usuario? usuarioLogado = Usuario();

  @override
  State<LoginFormPage> createState() => _LoginFormPageState();
}

class _LoginFormPageState extends State<LoginFormPage> {
  final UsuariosDb = UsuarioHelperApi();
  // final _nomeCon = TextEditingController();
  final _emailCon = TextEditingController();
  final _senhaCon = TextEditingController();

  @override
  void initState() {
    super.initState();
    // _nomeCon.text = widget.usuarioLogado!.nome!;
    _emailCon.text = widget.usuarioLogado!.email!;
    _senhaCon.text = widget.usuarioLogado!.senha!;
  }

  void login() {
    // widget.usuarioLogado!.nome = _nomeCon.text;
    widget.usuarioLogado!.email = _emailCon.text;
    widget.usuarioLogado!.senha = _senhaCon.text;
    // widget.usuarioLogado!.interesses = [];
    // Navigator.pop(context, 'Salvar');
    UsuariosDb.login(widget.usuarioLogado!).then((res) {
      Dialogos.showAlertDialog(context, 'Login realizado com sucesso!');
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => HomePage(usuarioLogado: res),
          ),
        );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // TextFormField(
            //   controller: _nomeCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'Nome',
            //   ),
            // ),
            TextFormField(
              controller: _emailCon,
              keyboardType: TextInputType.text,
              maxLength: 20,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Email',
              ),
            ),
            TextFormField(
              controller: _senhaCon,
              keyboardType: TextInputType.text,
              maxLength: 20,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Senha',
              ),
            ),
            // TextFormField(
            //   controller: _interessesCon,
            //   keyboardType: TextInputType.text,
            //   maxLength: 20,
            //   decoration: const InputDecoration(
            //     border: OutlineInputBorder(),
            //     labelText: 'interesses',
            //   ),
            // ),
            Row(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    child: const Text('Voltar'),
                    onPressed: () {
                      Navigator.pop(context, 'Voltar');
                    },
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    child: const Text('Entrar'),
                    onPressed: () {
                      login();
                    },
                  ),
                ),
                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: ElevatedButton(
                //     child: const Text('Excluir'),
                //     onPressed: () {
                //       Navigator.pop(context, 'Excluir');
                //     },
                //   ),
                // ),
              ],
            )
          ],
        )),
      ),
    );
  }
}
