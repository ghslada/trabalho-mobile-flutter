import 'package:app_trabalho/model/usuario.dart';
import 'package:app_trabalho/sqlite/mensagem_form.dart';
// import 'package:app_trabalho/sqlite/usuario_edit_page.dart';
// import 'package:app_trabalho/sqlite/usuarios_edit_page.dart';
import 'package:app_trabalho/sqlite/usuario_helper_api.dart';
import 'package:app_trabalho/util/dialogos.dart';
import 'package:flutter/material.dart';

class UsuariosListPage extends StatefulWidget {

  const UsuariosListPage({super.key, this.title, this.usuarioLogado});
  final String? title;
  final Usuario? usuarioLogado;

  @override
  State<UsuariosListPage> createState() => _UsuariosListPageState();
}

class _UsuariosListPageState extends State<UsuariosListPage> {
  final UsuariosDb = UsuarioHelperApi();
  List<Usuario> usuarios = List.empty();
  Usuario? selecionado;
  Usuario? usuarioLogado = Usuario();

  void _getAllContacts() {
    // UsuariosDb.obterTodos().then((list) {
    //   setState(() {
    //     Usuarios = list;
    //   });
    // });
    usuarioLogado = widget.usuarioLogado!;
    UsuariosDb.obterTodos().then((list) {
      setState(() {
        usuarios = list;
      });
    });
  }

  @override
  void initState() {
    
    super.initState();
    _getAllContacts();

  }

  selecionar(int selecao) {
    selecionado = usuarios[selecao];
    _showContactPage();
  }

  void _incluir() {
    selecionado = Usuario();
    _showContactPage();
  }

  void _showContactPage() async {
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => MensagemPage(
                  selecionado: selecionado,
                  usuarioLogado: usuarioLogado,
                )));
    if (result != null) {
      if (result == 'Salvar') {
        if (selecionado!.id == null) {
          // UsuariosDb.inserir(selecionado!).then((_) {
          //   _getAllContacts();
          //   Dialogos.showAlertDialog(context, 'Dados inseridos com sucesso!');
          // });
          UsuariosDb.inserir(selecionado!).then((res) {
            Dialogos.showAlertDialog(context, 'Dados inseridos com sucesso!');
          });
        } else {
          // UsuariosDb.alterar(selecionado!).then((_) {
          //   _getAllContacts();
          //   Dialogos.showAlertDialog(context, 'Dados alterados com sucesso!');
          // });
          UsuariosDb.alterar(selecionado!).then((res) {
            Dialogos.showAlertDialog(context, 'Dados alterados com sucesso!');
          });
        }
      } else if (result == 'Excluir') {
        // UsuariosDb.excluir(selecionado!.id!).then((_) {
        //   _getAllContacts();
        //   Dialogos.showAlertDialog(context, 'Dados excluídos com sucesso!');
        // });
        UsuariosDb.excluir(selecionado!.id!).then((res) {
          Dialogos.showAlertDialog(context, 'Dados excluídos com sucesso!');
        });
      } else if (result == 'Cancelar') {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Listagem"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Center(
          child: ListView.separated(
            padding: const EdgeInsets.only(right: 50.0),
            itemCount: usuarios.length,
            scrollDirection: Axis.vertical,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Row(children: <Widget>[
                  Text('${usuarios[index].id} - '),
                  // const SizedBox(width: 20),
                  Text(usuarios[index].nome!),
                ]),
                onTap: () => selecionar(index),
              );
            },
            separatorBuilder: (BuildContext context, int index) =>
                const Divider(),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incluir,
        tooltip: 'incluir',
        child: const Icon(Icons.add),
      ),
    );
  }
}
