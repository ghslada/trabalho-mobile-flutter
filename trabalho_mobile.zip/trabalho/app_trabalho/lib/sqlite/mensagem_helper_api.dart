import 'package:app_trabalho/model/mensagem.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MensagemHelperApi {
  String uri = "http://localhost:3000";
  Future<List<Mensagem>> obterTodos(criadoPor, enviadoPara) async {
    final res = await http.get(Uri.parse('$uri/Mensagem?'+'criadaPor='+criadoPor+'&enviadaPara='+enviadoPara));
    if (res.statusCode == 200) {
      List jsonList = json.decode(res.body);
      List<Mensagem> listContact = List.empty(growable: true);
      for (Map<String, dynamic> m in jsonList) {
        print(m);
        Mensagem c = Mensagem.fromMap(m);
        listContact.add(c);
      }
      return listContact;
    } else {
      throw Exception('Erro ao recuperar os objetos.');
    }
    // return [];
  }

  Future<Mensagem?> inserir(Mensagem contact) async {

    Map<String, dynamic> reqbody = contact.toMap();

    print(reqbody);

    final res = await http.post(Uri.parse('$uri/Mensagem'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(reqbody));
        print(jsonDecode(res.body));
    return Mensagem.fromMap(jsonDecode(res.body));
    // return Mensagem();
  }

  Future<Mensagem?> login(Mensagem contact) async {
    final res = await http.post(Uri.parse('$uri/Mensagem/login'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(contact.toMap()));
    return Mensagem.fromMapPopulated(jsonDecode(res.body));
    // return Mensagem();
  }

  Future<String?> alterar(Mensagem contact) async {
    final res = await http.put(Uri.parse('$uri/Mensagem'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(contact.toMap()));
    final body =  jsonDecode(res.body);

    return body._id;
    // return 0;
  }

  Future<String> excluir(String idDel) async {
    final res = await http.delete(Uri.parse('$uri/Mensagem/$idDel'));
    final body =  jsonDecode(res.body);

    return body._id;
    // return res.body;
    // return 0;
  }

  Future<Mensagem> getObjeto(int idFind) async {
      final res = await http.get(Uri.parse('$uri/Mensagem/$idFind'));
      if (res.statusCode == 200) {
        Mensagem c = Mensagem.fromMap(jsonDecode(res.body));
        return c;
      } else {
        throw Exception('Erro ao recuperar o objeto.');
      }
    // return Mensagem();

  }

}
