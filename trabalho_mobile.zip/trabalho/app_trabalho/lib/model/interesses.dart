import 'package:app_trabalho/model/usuario.dart';

class Interesse {
  String? id;
  String? titulo;
  String? descricao;
  Usuario? criadoPor;
  // List? interesse;

  Interesse() {
    id = null;
    titulo = "";
    descricao = "";
    criadoPor = Usuario();
    // interesse = [];
  }

  Interesse.init(this.id, this.titulo, this.descricao, this.criadoPor);

  factory Interesse.fromMap(Map<String, dynamic> json) {
    return Interesse.init(
        json['id'], json['titulo'], json['descricao'], json['criadoPor']);
  }

  Map<String, dynamic> toMap() =>
      {'id': id, 'titulo': titulo, 'descricao': descricao, 'criadoPor': criadoPor};

  @override
  toString() {
    return '$titulo - $descricao';
  }

  bool operator ==(other) {
    return (other is Interesse && other.id == id);
  }
}
