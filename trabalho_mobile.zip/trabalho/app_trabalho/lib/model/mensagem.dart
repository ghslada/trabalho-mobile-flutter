import 'package:app_trabalho/model/usuario.dart';

class Mensagem {
  String? id;
  // String? titulo;
  String? descricao;
  String? criadoPor;
  List<String>? enviadaPara;
  List<Usuario>? enviadaParaPopulated;
  Usuario? criadoPorPopulated;
  List? curtidas;

  Mensagem() {
    id = null;
    descricao = "";
    criadoPor = '';
    enviadaPara = [];
    curtidas = [];
  }

  Mensagem.init(
      this.id, this.descricao, this.criadoPor, enviadaPara, this.curtidas);

  Mensagem.initPopulated(
      this.id, this.descricao, this.criadoPorPopulated, enviadaParaPopulated, this.curtidas);

  factory Mensagem.fromMap(Map<String, dynamic> json) {
    return Mensagem.init(json['id'], json['descricao'], json['criadaPor'],
        json['enviadaPara'], json['curtidas']);
  }

  factory Mensagem.fromMapPopulated(Map<String, dynamic> json) {
    return Mensagem.initPopulated(json['id'], json['descricao'], json['criadaPor'],
        json['enviadaPara'], json['curtidas']);
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'descricao': descricao,
        'criadaPor': criadoPor,
        'enviadaPara': enviadaPara,
        'curtidas': curtidas
      };

  Map<String, dynamic> toMapPopulated() => {
        'id': id,
        'descricao': descricao,
        'criadaPor': criadoPorPopulated,
        'enviadaPara': enviadaParaPopulated,
        'curtidas': curtidas
      };

  @override
  toString() {
    return '$descricao';
  }

  bool operator ==(other) {
    return (other is Mensagem && other.id == id);
  }
}
