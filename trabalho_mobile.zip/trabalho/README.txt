Passo 1: Instalar o servidor MongoDB 6.0 local e executar o arquivo "mongod.bat".

Passo 2: Instalar as dependencias da API executando o comando "npm install" dentro do diretório "predios-api".

Passo 3: Iniciar o serviço da API utilizando o comando "npm run start" dentro do diretório "predios-api".